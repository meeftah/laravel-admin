# PPDB Al-Fityan Kubu Raya

# How to use
- Klon Project.
- Sesuai .env.example file to .env and edit database credentials there
- Then run the command
- ``` composer install . ```
- Run ``` php artisan key:generate ``` 
- Run ``` php artisan migrate --seed ``` 
- Done! Login with ``` "admin@admin.com" ``` and ``` "password" ```

# Licence
The <a href="http://opensource.org/licenses/MIT">MIT license.</a>
