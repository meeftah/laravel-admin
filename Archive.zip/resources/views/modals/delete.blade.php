<div class="modal fade" id="confirm-delete" data-backdrop="static" data-keyboard="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header panel-heading bg-danger text-center">
                <h4 class="modal-title text-white">Hapus Data</h4>
            </div>
            <div class="modal-body">
                <p>Apakah anda yakin ingin menghapus data ini?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-warning" data-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-sm btn-danger" id="delete-btn">Ya, Hapus</button>
            </div>
        </div>
    </div>
</div>