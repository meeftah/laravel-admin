$( document ).ready(function() {
    $(".select-tags").selectize();


    $('.dataTable').DataTable();
});