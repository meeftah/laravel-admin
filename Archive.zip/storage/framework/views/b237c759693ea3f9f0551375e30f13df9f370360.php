<div class="form-group">
    <label for="<?php echo e($name); ?>"><?php echo e($capital); ?></label>
    <input type="<?php echo e($type); ?>" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
           class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>"
           <?php echo e($isRequired); ?>

            <?php echo e($attributes); ?>

        >

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/components/input.blade.php ENDPATH**/ ?>