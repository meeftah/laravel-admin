<div class="row align-items-center">
    <div class="col-lg-3 ml-auto">
        
        
        
        
        
        
        
    </div>
    <div class="col-lg order-lg-first">
        <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
            <li class="nav-item">
                <a href="<?php echo e(route('dashboard.home')); ?>" class="nav-link">
                    <i class="fe fe-home"></i> Home
                </a>
            </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="dropdown"><i class="fe fe-users"></i> Users</a>
                    <div class="dropdown-menu dropdown-menu-arrow">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions_lihat')): ?>
                        <a href="<?php echo e(route('dashboard.permissions.index')); ?>" class="dropdown-item ">Permissions</a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_lihat')): ?>
                        <a href="<?php echo e(route('dashboard.roles.index')); ?>" class="dropdown-item ">Roles</a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users_lihat')): ?>
                            <a href="<?php echo e(route('dashboard.users.index')); ?>" class="dropdown-item ">Users</a>
                        <?php endif; ?>
                    </div>
                </li>
        </ul>
    </div>
</div><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/dashboard/partials/menu.blade.php ENDPATH**/ ?>