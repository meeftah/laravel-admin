<!-- ########## START: HEAD PANEL ########## -->
<div class="br-header">
    <div class="br-header-left">
        <div class="navicon-left hidden-md-down">
            <a id="btnLeftMenu" href="">
                <i class="icon ion-navicon-round"></i>
            </a>
        </div>
        <div class="navicon-left hidden-lg-up">
            <a id="btnLeftMenuMobile" href="">
                <i class="icon ion-navicon-round"></i>
            </a>
        </div>
        <div class="mt-3 ml-3">
            <h5><?php echo e(get_greeting()); ?>, <?php echo e(Auth::user()->name); ?></h5>
        </div>
        
    </div><!-- br-header-left -->
</div><!-- br-header -->
<!-- ########## END: HEAD PANEL ########## --><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/partials/headbar.blade.php ENDPATH**/ ?>