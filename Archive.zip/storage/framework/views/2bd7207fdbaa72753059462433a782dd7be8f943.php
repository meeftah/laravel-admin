<!-- ########## START: LEFT PANEL ########## -->
<div class="br-logo justify-content-center">
    <a href="<?php echo e(route('dashboard.home')); ?>">
        <img src="<?php echo e(asset('assets/common/logo-text.png')); ?>" height="50px">
    </a>
</div>

<div class="br-sideleft overflow-y-auto">
    <label class="sidebar-label pd-x-15 mg-t-20">Navigasi</label>
    <div class="br-sideleft-menu">
        <a href="<?php echo e(route('dashboard.home')); ?>"
            class="br-menu-link <?php echo e(set_active([Request::is('dashboard/home'), Request::is('dashboard/home/')])); ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
                <span class="menu-item-label">Beranda</span>
            </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <?php if(auth()->check() && auth()->user()->hasAnyRole('calonsiswa_tk|calonsiswa_sd|calonsiswa_smp|calonsiswa_sma')): ?>
        <a href="<?php echo e(route('dashboard.calonsiswa.profil', Auth::user()->id)); ?>"
            class="br-menu-link <?php echo e(set_active(Request::is('dashboard/calon-siswa/profil*'))); ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
                <span class="menu-item-label">Profil Calon Siswa</span>
            </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <?php endif; ?>
        <?php if(auth()->user()->can('users_lihat') || auth()->user()->can('roles_lihat') ||
        auth()->user()->can('permissions_lihat')): ?>
        <a href="javascript: void(0);"
            class="br-menu-link <?php echo e(set_active([Request::is('dashboard/users*'), Request::is('dashboard/roles*'), Request::is('dashboard/permissions*')], 'active show-sub')); ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-people tx-24"></i>
                <span class="menu-item-label">Manajemen User</span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <ul class="br-menu-sub nav flex-column">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.users.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/users*'))); ?>">Pengguna</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.roles.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/roles*'))); ?>">Peran</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.permissions.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/permissions*'))); ?>">Hak Akses</a></li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>


        <?php if(auth()->user()->can('penghasilan_lihat') || auth()->user()->can('pekerjaan_lihat') || auth()->user()->can('pendidikan_lihat') || auth()->user()->can('agama_lihat') || auth()->user()->can('alamat_lihat') || auth()->user()->can('kondisibelajar') || auth()->user()->can('bcquran') || auth()->user()->can('waktutmph') || auth()->user()->can('jenisdokumen') || auth()->user()->can('transportasi') || auth()->user()->can('tempattinggal')): ?>
        <a href="#" class="br-menu-link <?php echo e(set_active([Request::is('dashboard/penghasilan*'), Request::is('dashboard/pekerjaan*'), Request::is('dashboard/pendidikan*'), Request::is('dashboard/agama*'), Request::is('dashboard/jarak*'), Request::is('dashboard/kondisibelajar*'), Request::is('dashboard/bcquran*'), Request::is('dashboard/waktutmph*'), Request::is('dashboard/jenisdokumen*'), Request::is('dashboard/transportasi*'), Request::is('dashboard/tempattinggal*')], 'active show-sub')); ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-filing tx-24"></i>
                <span class="menu-item-label">Master Data</span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <ul class="br-menu-sub nav flex-column">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('penghasilan_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.penghasilan.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/penghasilan*'))); ?>">Data Penghasilan</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pekerjaan_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.pekerjaan.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/pekerjaan*'))); ?>">Data Pekerjaan</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pendidikan_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.pendidikan.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/pendidikan*'))); ?>">Data Pendidikan</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agama_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.agama.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/agama*'))); ?>">Data Agama</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jarak_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.jarak.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/jarak*'))); ?>">Data Jarak Tempat Tinggal</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kondisibelajar_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.kondisibelajar.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/kondisibelajar*'))); ?>">Data Kondisi Belajar</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bcquran_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.bcquran.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/bcquran*'))); ?>">Data Bacaan Quran</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('waktutmph_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.waktutmph.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/waktutmph*'))); ?>">Data Waktu Tempuh</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jenisdokumen_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.jenisdokumen.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/jenisdokumen*'))); ?>">Data Jenis Dokumen</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transportasi_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.transportasi.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/transportasi*'))); ?>">Data Trasportasi</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tempattinggal_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.tempattinggal.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/tempattinggal*'))); ?>">Data Tempat Tinggal</a>
            </li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>

        
        <?php if(auth()->user()->can('vatk_lihat') || auth()->user()->can('vasd_lihat') || auth()->user()->can('vasmp_lihat') || auth()->user()->can('vasma_lihat')): ?>
        <a href="javascript: void(0);"
            class="br-menu-link <?php echo e(set_active([Request::is('dashboard/va/tk*'), Request::is('dashboard/va/sd*'), Request::is('dashboard/va/smp*'), Request::is('dashboard/va/sma*')], 'active show-sub')); ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon icon ion-ios-people tx-24"></i>
                <span class="menu-item-label">Virtual Account</span>
                <i class="menu-item-arrow fa fa-angle-down"></i>
            </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <ul class="br-menu-sub nav flex-column">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vatk_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.va.tk.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/va/tk*'))); ?>">VA TK</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vasd_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.va.sd.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/va/sd*'))); ?>">VA SD</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vasmp_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.va.smp.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/va/smp*'))); ?>">VA SMP</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vasma_lihat')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.va.sma.index')); ?>"
                    class="nav-link <?php echo e(set_active(Request::is('dashboard/va/sma*'))); ?>">VA SMA</a></li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>
        

        <a href="javascript: void(0);" class="br-menu-link text-danger" data-toggle="modal" data-target="#logoutModal"">
            <div class=" br-menu-item">
            <i class="menu-item-icon icon ion-log-out tx-22"></i>
            <span class="menu-item-label">Logout</span>
    </div><!-- br-sideleft-menu -->
    <br>
</div><!-- br-sideleft -->
</div><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>