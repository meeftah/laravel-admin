<footer class="br-footer">
    <div class="footer-left">
        <div class="mg-b-2">Copyright &copy;
            <script type="text/javascript">
                document.write(new Date().getFullYear());
            </script>. PPDB Al-Fityan Kubu Raya. All Rights Reserved.
        </div>
    </div>
    
</footer><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/partials/footer.blade.php ENDPATH**/ ?>