<?php $__env->startSection('breadcrumb'); ?>
<div class="br-pageheader pd-y-15 pd-l-20">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="index.html">Bracket</a>
        <span class="breadcrumb-item active">Blank Page</span>
    </nav>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
    <h4 class="tx-gray-800 mg-b-5">Dashboard</h4>
    <p class="mg-b-0">Halaman beranda PPDB Al-Fityan Kubu Raya</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/dashboard/dashboard/index.blade.php ENDPATH**/ ?>