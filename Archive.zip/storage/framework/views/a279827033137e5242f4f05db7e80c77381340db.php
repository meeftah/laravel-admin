<script>

    $(document).ready(function () {

        toastr.options = {
            "timeOut": "1000"
        };

        <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>


        <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>


        <?php if(Session::has('warning')): ?>
        toastr.warning("<?php echo e(Session::get('warning')); ?>");
        <?php endif; ?>


        <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>

    });

</script><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/admin/partials/notifications.blade.php ENDPATH**/ ?>