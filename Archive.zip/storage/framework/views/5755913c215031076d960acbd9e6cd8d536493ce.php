<?php $__env->startSection('body'); ?>
<?php echo $__env->make('partials.headbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ########## START: MAIN PANEL ########## -->
<div class="br-mainpanel">
    <?php echo $__env->yieldContent('breadcrumb'); ?>
    <?php echo $__env->yieldContent('content-header'); ?>

    <div class="br-pagebody">
        <?php echo $__env->yieldContent('content'); ?>
    </div><!-- br-pagebody -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><!-- br-mainpanel -->
<?php echo $__env->make('modals.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ########## END: MAIN PANEL ########## -->

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('assets/dashboard/lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/dashboard/lib/jquery-switchbutton/jquery.switchButton.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/dashboard/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/moment/moment.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/jquery-switchbutton/jquery.switchButton.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/peity/jquery.peity.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/highlightjs/highlight.pack.js')); ?>"></script>
<?php echo $__env->make('partials.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('assets/dashboard/js/bracket.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/layouts/admin.blade.php ENDPATH**/ ?>