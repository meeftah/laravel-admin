<?php $__env->startSection('title', 'Daftar Data Jarak'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="br-pageheader pd-y-15 pd-l-20">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('dashboard.jarak.index')); ?>">Data Jarak</a>
    </nav>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
    <h4 class="tx-gray-800 mg-b-5">Data Jarak</h4>
    <p class="mg-b-0">Master data jarak</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12 col-md-4 mb-5">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route("dashboard.jarak.store")); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-control-label">Kode: <span class="tx-danger">*</span></label>
                        <input class="form-control <?php echo e($errors->has('kode') ? 'is-invalid' : ''); ?>" type="text"
                            name="kode" placeholder="Masukkan kode" value="<?php echo e(old('kode', null)); ?>">
                        <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Jarak: <span class="tx-danger">*</span></label>
                        <input class="form-control <?php echo e($errors->has('jarak') ? 'is-invalid' : ''); ?>" type="text"
                            name="jarak" placeholder="Masukkan data jarak"
                            value="<?php echo e(old('jarak', null)); ?>">
                        <?php $__errorArgs = ['jarak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-layout-footer">
                        <button class="btn btn-success col-sm-12 col-md-6">Simpan</button>
                    </div><!-- form-layout-footer -->
                </form>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-8">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered dt-responsive nowrap" data-form="deleteForm"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;" id="datatable-jarak">
                        <thead>
                            <tr class="text-uppercase">
                                <th></th>
                                <th>No</th>
                                <th>KODE</th>
                                <th>TEMPAT TINGGAL</th>
                                <?php if(auth()->user()->can('jarak_detail') || auth()->user()->can('jarak_ubah')
                                ||
                                auth()->user()->can('jarak_hapus')): ?>
                                <th width="150">AKSI</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('assets/dashboard/lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/dashboard/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/dashboard/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/dashboard/lib/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/datatables-responsive/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/select2/js/select2.min.js')); ?>"></script>
<script>
    $(document).ready( function () {
        $('#datatable-jarak').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            language: {
                url: 'http://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json',
            },
            ajax: "<?php echo e(route('dashboard.jarak.api')); ?>",
            columns: [
                { data: 'id_jarak', name: 'id_jarak', visible: false },
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable:false, serachable:false },
                { data: 'kode', name: 'kode' },
                { data: 'jarak', name: 'jarak' },
                <?php if(auth()->user()->can('jarak_detail') || auth()->user()->can('jarak_ubah') || auth()->user()->can('jarak_hapus')): ?>
                { data: 'action', name: 'action', orderable:false, serachable:false }
                <?php endif; ?>
            ],
            columnDefs: [
                { className: 'text-center', width: 30, targets: [1] },
                { className: 'text-center', width: 60, targets: [2] },
                <?php if(auth()->user()->can('jarak_detail') || auth()->user()->can('jarak_ubah') || auth()->user()->can('jarak_hapus')): ?>
                { className: 'text-center', targets: [4] },
                <?php endif; ?>
            ],
            order: [],
        });
    });
</script>
<script>
    var id_delete;
    $(document).on('click', '.delete', function(){
        id_delete = $(this).attr('id');
        $('#confirm-delete').modal('show');
    });

    $('#delete-btn').click(function(){
        $.ajax({
            url: 'jarak/' + id_delete,
            type: 'POST',
            data: {
                _method:'DELETE'
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success:function(data){
                $('#confirm-delete').modal('hide');
                $('#datatable-jarak').DataTable().ajax.reload();
                if (data.status == 'success') {
                    toastr.success(data.message);
                } else {
                    toastr.error(data.message);
                }
            },
        })
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/dashboard/masterdata/jarak/index.blade.php ENDPATH**/ ?>