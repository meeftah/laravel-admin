<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-10">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">All Roles</h4>
                        <div class="card-options">
                            <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-xs btn-outline-primary">Create
                                Role</a>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table card-table table-striped table-vcenter">
                            <thead>
                            <tr>
                                <th>
                                    ID
                                </th>
                                <th>
                                    Role
                                </th>
                                <th>
                                    Permissions
                                </th>
                                <th>
                                    &nbsp;
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($role->id); ?>">
                                    <td>
                                        <?php echo e($role->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e(ucfirst($role->name)); ?>

                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $role->permissions()->pluck('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-info"><?php echo e($permission); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <a class="icon"
                                           href="<?php echo e(route('admin.roles.edit', $role->id)); ?>">
                                            <i class="fe fe-edit"></i> Edit
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>