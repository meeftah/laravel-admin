<?php $__env->startSection('title', 'Daftar Data Jenis Dokumen'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="br-pageheader pd-y-15 pd-l-20">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?php echo e(route('dashboard.jenisdokumen.index')); ?>">Data Jenis Dokumen</a>
    </nav>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<div class="pd-x-20 pd-sm-x-30 pd-t-20 pd-sm-t-30">
    <h4 class="tx-gray-800 mg-b-5">Data Jenis Dokumen</h4>
    <p class="mg-b-0">Master data Jenis Dokumen</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12 col-md-4 mb-5">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route("dashboard.jenisdokumen.store")); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="form-control-label">Jenis Dokumen: <span class="tx-danger">*</span></label>
                        <input class="form-control <?php echo e($errors->has('jenisdokumen') ? 'is-invalid' : ''); ?>" type="text"
                            name="jenisdokumen" placeholder="Masukkan data jenis dokumen"
                            value="<?php echo e(old('jenisdokumen', null)); ?>">
                        <?php $__errorArgs = ['jenisdokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Unit: <span class="tx-danger">*</span></label>
                        <select name="unit" class="form-control select2-show-search" style="width: 100%"
                            data-placeholder="Pilih Unit">
                            <option></option>
                            <option value="TK">TKIT</option>
                            <option value="SD">SDIT</option>
                            <option value="SMP">SMPIT</option>
                            <option value="SMA">SMAIT</option>
                        </select>
                    </div>

                    <div class="form-layout-footer">
                        <button class="btn btn-success col-sm-12 col-md-6">Simpan</button>
                    </div><!-- form-layout-footer -->
                </form>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-8">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered dt-responsive nowrap" data-form="deleteForm"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;" id="datatable-jenisdokumen">
                        <thead>
                            <tr class="text-uppercase">
                                <th></th>
                                <th>No</th>
                                <th>JENIS DOKUMEN</th>
                                <th>UNIT</th>
                                <?php if(auth()->user()->can('jenisdokumen_detail') ||
                                auth()->user()->can('jenisdokumen_ubah')
                                ||
                                auth()->user()->can('jenisdokumen_hapus')): ?>
                                <th width="150">AKSI</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('assets/dashboard/lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/dashboard/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/dashboard/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/dashboard/lib/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/datatables-responsive/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/lib/select2/js/select2.min.js')); ?>"></script>
<script>
    $(document).ready( function () {
        $('#datatable-jenisdokumen').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            language: {
                url: 'http://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json',
            },
            ajax: "<?php echo e(route('dashboard.jenisdokumen.api')); ?>",
            columns: [
                { data: 'id_jenisdokumen', name: 'id_jenisdokumen', visible: false },
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable:false, serachable:false },
                { data: 'jenisdokumen', name: 'jenisdokumen' },
                { data: 'unit', name: 'unit' },
                <?php if(auth()->user()->can('jenisdokumen_detail') || auth()->user()->can('jenisdokumen_ubah') || auth()->user()->can('jenisdokumen_hapus')): ?>
                { data: 'action', name: 'action', orderable:false, serachable:false }
                <?php endif; ?>
            ],
            columnDefs: [
                { className: 'text-center', width: 20, targets: [1] },
                { width: 400, targets: [2] },
                { className: 'text-center', width: 50, targets: [3] },
                <?php if(auth()->user()->can('jenisdokumen_detail') || auth()->user()->can('jenisdokumen_ubah') || auth()->user()->can('jenisdokumen_hapus')): ?>
                { className: 'text-center', targets: [4] },
                <?php endif; ?>
            ],
            order: [],
        });
    });
</script>
<script>
    var id_delete;
    $(document).on('click', '.delete', function(){
        id_delete = $(this).attr('id');
        $('#confirm-delete').modal('show');
    });

    $('#delete-btn').click(function(){
        $.ajax({
            url: 'jenisdokumen/' + id_delete,
            type: 'POST',
            data: {
                _method:'DELETE'
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success:function(data){
                $('#confirm-delete').modal('hide');
                $('#datatable-jenisdokumen').DataTable().ajax.reload();
                if (data.status == 'success') {
                    toastr.success(data.message);
                } else {
                    toastr.error(data.message);
                }
            },
        })
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Disket/Work/APPs/WebDev/ppdb/resources/views/dashboard/masterdata/jenisdokumen/index.blade.php ENDPATH**/ ?>